-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 10.35.47.22:3306
-- Erstellungszeit: 02. Okt 2022 um 12:09
-- Server-Version: 8.0.30
-- PHP-Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `k42028_cloud`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_totals`
--

DROP TABLE IF EXISTS `MGP_totals`;
CREATE TABLE `MGP_totals` (
  `UID` tinyint NOT NULL,
  `Score` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tabellenstruktur für Tabelle `MGP_scores`
--

DROP TABLE IF EXISTS `MGP_scores`;
CREATE TABLE `MGP_scores` (
  `UID` tinyint NOT NULL,
  `EID` tinyint NOT NULL,
  `Score` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Tabellenstruktur für Tabelle `MGP_riders`
--

DROP TABLE IF EXISTS `MGP_riders`;
CREATE TABLE `MGP_riders` (
  `RID` tinyint NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Vorname` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `MGP_riders`
--

INSERT INTO `MGP_riders` (`RID`, `Name`, `Vorname`) VALUES
(5, 'Zarco', 'Johann'),
(6, 'Bradl', 'Stefan'),
(10, 'Marini', 'Luca'),
(12, 'Vinales', 'Maverick'),
(20, 'Quartararo', 'Fabio'),
(21, 'Morbidelli', 'Franco'),
(23, 'Bastianini', 'Enea'),
(25, 'Fernandez', 'Raul'),
(30, 'Nakagami', 'Takaaki'),
(33, 'Binder', 'Brad'),
(36, 'Mir', 'Joan'),
(40, 'Binder', 'Darryn'),
(41, 'Espargaro', 'Aleix'),
(42, 'Rins', 'Alex'),
(43, 'Miller', 'Jack'),
(44, 'Espargaro', 'Pol'),
(49, 'diGianantonio', 'Fabio'),
(63, 'Bagnaia', 'Francesco'),
(72, 'Bezecchi', 'Marco'),
(73, 'Marquez', 'Alex'),
(87, 'Gardner', 'Remy'),
(88, 'Oliveira', 'Miguel'),
(89, 'Martin', 'Jorge'),
(93, 'Marquez', 'Marc');

--
-- Tabellenstruktur für Tabelle `MGP_users`
--

DROP TABLE IF EXISTS `MGP_users`;
CREATE TABLE `MGP_users` (
  `UID` tinyint NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Vorname` varchar(64) NOT NULL,
  `Nickname` varchar(64) NOT NULL,
  `Email` varchar(64) NOT NULL,
  `Passwort` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `MGP_users`
--

INSERT INTO `MGP_users` (`UID`, `Name`, `Vorname`, `Nickname`, `Email`, `Passwort`) VALUES
(1, 'Joss', 'Werner', 'Gegge04', 'werner@hoernerfranzracing.de', '1242'),
(2, 'Rendier', 'Udo', 'Uedoh_32', 'chezmoto32@gmail.com', '1234'),
(3, 'Metz', 'Bodo', 'Bodo63', 'bodo.metz@gmx.de', '1234'),
(4, 'Hauke', 'Christian', 'Chris24', 'chris.hauke@gmx.de', '1234'),
(5, 'Friedrich', 'Wolfgang', 'Pepsi15', 'wolfgang.d.friedrich@alice-dsl.net', '1234'),
(6, 'Treuz', 'Jochen', 'Jochen06', 'info@treuz.de', '1234'),
(7, 'StaengleDup', 'Rene', 'ReneDup', 'rene.staengle@gmail.com', '1234'),
(8, 'Beaujean', 'Damian', 'Dammi48', 'beaujean@ph1.uni-koeln.de', '1234'),
(9, 'Staengle', 'Rene', 'Rene19', 'renestaengle@gmail.com', '1234'),
(10, 'Reinacher', 'Andreas', 'Andi30', 'andi.reinacher@web.de', '1234'),
(11, 'Hauf', 'Martin', 'Maddl41', 'martin.hauf@gmx.de', '1234'),
(12, 'Hoffmann', 'Michael', 'Micha22', 'michael.h.hoffmann@kabelbw.de', '123456'),
(13, 'Bohland', 'Volker', 'VolkerB01', 'volker.bohland@t-online.de', '12345'),
(14, 'Joss', 'Peter', 's0wbear', 's0w890@gmail.com', '123456'),
(15, 'Sellentin', 'Alexander', 'Selle45', 'kaselle@gmx.de', '123456'),
(16, 'Schroth', 'Martin', 'Martin33', 'martin_schroth@web.de', '123456'),
(17, 'Ratzel', 'Bernd', 'BerndR41', 'b.ratzel@gmx.de', '123456'),
(18, 'Amberg', 'Juergen', 'Kuntz01', 'juergen.amberg@t-online.de', '123456'),
(19, 'Bartsch', 'Julian', 'JuBa91', 'racing091@gmx.de', '123456');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `MGP_users`
--
ALTER TABLE `MGP_users`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `MGP_users`
--
ALTER TABLE `MGP_users`
  MODIFY `UID` tinyint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 10.35.47.22:3306
-- Erstellungszeit: 07. Nov 2022 um 15:33
-- Server-Version: 8.0.30
-- PHP-Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `k42028_cloud`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_events`
--

DROP TABLE IF EXISTS `MGP_events`;
CREATE TABLE `MGP_events` (
  `EID` tinyint NOT NULL,
  `Ort` varchar(64) NOT NULL,
  `Deadline` datetime NOT NULL,
  `P1` tinyint DEFAULT NULL,
  `P2` tinyint DEFAULT NULL,
  `P3` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `MGP_events`
--

INSERT INTO `MGP_events` (`EID`, `Ort`, `Deadline`, `P1`, `P2`, `P3`) VALUES
(1, 'Doha', '2022-03-06 10:00:00', 23, 33, 44),
(2, 'Mandalika', '2022-03-20 10:00:00', 88, 20, 5),
(3, 'Termas', '2022-04-03 10:00:00', 41, 89, 42),
(4, 'Austin', '2022-04-10 10:00:00', 23, 42, 43),
(5, 'Portimao', '2022-04-24 13:00:00', 20, 5, 41),
(6, 'Jerez', '2022-05-01 13:00:00', 63, 20, 41),
(7, 'LeMans', '2022-05-15 13:00:00', 23, 43, 41),
(8, 'Mugello', '2022-05-29 13:00:00', 63, 20, 41),
(9, 'Catalunya', '2022-06-05 13:00:00', 20, 89, 5),
(10, 'Sachsenring', '2022-06-19 13:00:00', 20, 5, 43),
(11, 'Assen', '2022-06-26 13:00:00', 63, 72, 12),
(12, 'Silverstone', '2022-08-07 13:00:00', 63, 12, 43),
(13, 'RedBullRing', '2022-08-21 13:00:00', 63, 20, 43),
(14, 'Misano', '2022-09-04 13:00:00', 63, 23, 12),
(15, 'Aragon', '2022-09-18 13:00:00', 23, 63, 41),
(16, 'Motegi', '2022-09-25 07:00:00', 43, 33, 89),
(17, 'Buriram', '2022-10-02 09:00:00', 88, 43, 63),
(18, 'PI', '2022-10-16 04:00:00', 42, 93, 63),
(19, 'Sepang', '2022-10-23 08:00:00', 63, 23, 20),
(20, 'Valencia', '2022-11-06 13:00:00', 42, 33, 89);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `MGP_events`
--
ALTER TABLE `MGP_events`
  ADD PRIMARY KEY (`EID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 10.35.47.22:3306
-- Erstellungszeit: 07. Nov 2022 um 15:33
-- Server-Version: 8.0.30
-- PHP-Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `k42028_cloud`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_tips`
--

DROP TABLE IF EXISTS `MGP_tips`;
CREATE TABLE `MGP_tips` (
  `TID` smallint DEFAULT NULL,
  `EID` tinyint NOT NULL,
  `UID` tinyint NOT NULL,
  `P1` tinyint DEFAULT NULL,
  `P2` tinyint DEFAULT NULL,
  `P3` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `MGP_tips`
--

INSERT INTO `MGP_tips` (`TID`, `EID`, `UID`, `P1`, `P2`, `P3`) VALUES
(1, 1, 1, 93, 36, 89),
(2, 1, 5, 23, 89, 93),
(3, 2, 1, 20, 33, 63),
(4, 2, 5, 5, 20, 63),
(5, 3, 1, 41, 89, 44),
(6, 3, 5, 41, 10, 20),
(7, 4, 1, 63, 89, 23),
(8, 4, 5, 89, 43, 93),
(9, 5, 1, 20, 36, 43),
(10, 5, 5, 20, 93, 36),
(11, 5, 3, 43, 20, 36),
(12, 5, 8, 36, 5, 93),
(13, 5, 9, 36, 43, 41),
(14, 5, 11, 41, 43, 20),
(15, 5, 6, 43, 93, 36),
(16, 5, 10, 36, 20, 93),
(17, 5, 2, 93, 36, 43),
(18, 6, 12, 20, 42, 5),
(19, 6, 5, 20, 63, 93),
(20, 6, 13, 12, 93, 73),
(21, 6, 3, 63, 20, 89),
(22, 6, 1, 63, 20, 5),
(23, 6, 4, 63, 20, 93),
(24, 6, 2, 63, 20, 93),
(25, 6, 9, 20, 63, 43),
(26, 6, 6, 63, 20, 43),
(27, 6, 11, 63, 20, 5),
(28, 6, 10, 63, 20, 36),
(29, 6, 8, 63, 20, 93),
(30, 7, 16, 63, 23, 20),
(31, 7, 1, 20, 63, 41),
(32, 7, 5, 63, 20, 41),
(33, 7, 3, 63, 20, 43),
(34, 7, 8, 63, 20, 41),
(35, 7, 4, 63, 43, 20),
(36, 7, 9, 63, 20, 43),
(37, 7, 13, 63, 41, 93),
(38, 7, 6, 63, 41, 20),
(39, 7, 2, 20, 43, 63),
(40, 7, 10, 63, 43, 41),
(41, 7, 14, 20, 41, 89),
(42, 8, 5, 63, 20, 5),
(43, 8, 3, 63, 41, 72),
(44, 8, 8, 63, 23, 20),
(45, 8, 2, 63, 49, 5),
(46, 8, 6, 49, 10, 43),
(47, 8, 10, 63, 23, 5),
(48, 8, 9, 49, 63, 72),
(49, 8, 14, 63, 23, 41),
(50, 8, 1, 63, 41, 5),
(51, 9, 5, 63, 20, 41),
(52, 9, 3, 41, 63, 20),
(53, 9, 9, 41, 20, 63),
(54, 9, 2, 63, 41, 20),
(55, 9, 1, 63, 41, 20),
(56, 9, 17, 63, 41, 20),
(57, 9, 6, 41, 20, 12),
(58, 9, 10, 41, 63, 20),
(59, 9, 14, 41, 63, 12),
(60, 10, 18, 43, 12, 20),
(61, 10, 5, 20, 63, 41),
(62, 10, 3, 63, 20, 89),
(63, 10, 1, 20, 41, 5),
(64, 10, 8, 63, 20, 5),
(65, 10, 13, 20, 63, 41),
(66, 10, 6, 20, 41, 63),
(67, 10, 9, 20, 41, 63),
(68, 10, 2, 63, 20, 5),
(69, 10, 17, 63, 20, 41),
(70, 10, 14, 63, 20, 41),
(71, 11, 10, 20, 63, 89),
(72, 11, 1, 20, 63, 72),
(73, 11, 3, 63, 20, 89),
(74, 11, 14, 20, 63, 89),
(75, 11, 17, 20, 63, 5),
(76, 11, 6, 20, 63, 41),
(77, 11, 9, 63, 20, 89),
(78, 11, 13, 63, 20, 41),
(79, 11, 2, 63, 20, 41),
(80, 12, 5, 20, 63, 12),
(81, 12, 16, 41, 43, 63),
(82, 12, 1, 12, 20, 5),
(83, 12, 11, 12, 63, 5),
(84, 12, 8, 5, 20, 63),
(85, 12, 3, 63, 43, 12),
(86, 12, 2, 20, 63, 5),
(87, 12, 14, 12, 5, 43),
(88, 12, 13, 5, 43, 12),
(89, 12, 6, 12, 20, 43),
(90, 13, 5, 63, 23, 12),
(91, 13, 3, 63, 43, 20),
(92, 13, 1, 63, 20, 43),
(93, 13, 8, 63, 23, 20),
(94, 13, 2, 63, 20, 23),
(95, 13, 17, 63, 23, 20),
(96, 13, 6, 63, 20, 43),
(97, 14, 3, 63, 23, 20),
(98, 14, 5, 63, 20, 12),
(99, 14, 2, 63, 23, 43),
(100, 14, 1, 63, 23, 20),
(101, 14, 8, 43, 23, 20),
(102, 14, 6, 23, 12, 63),
(103, 14, 14, 63, 20, 23),
(104, 14, 17, 63, 20, 23),
(105, 15, 1, 63, 23, 41),
(106, 15, 5, 63, 41, 23),
(107, 15, 3, 63, 23, 41),
(108, 15, 17, 63, 23, 43),
(109, 15, 2, 63, 23, 43),
(110, 15, 8, 63, 23, 20),
(111, 15, 6, 63, 23, 43),
(112, 15, 14, 63, 41, 23),
(113, 15, 10, 63, 23, 41),
(114, 16, 3, 93, 5, 63),
(115, 16, 5, 93, 5, 12),
(116, 16, 1, 93, 41, 5),
(117, 16, 14, 93, 5, 23),
(118, 16, 8, 93, 41, 33),
(119, 16, 17, 41, 93, 63),
(120, 16, 2, 89, 12, 20),
(121, 17, 3, 63, 72, 20),
(122, 17, 5, 63, 23, 93),
(123, 17, 1, 43, 20, 23),
(124, 17, 6, 63, 20, 43),
(125, 17, 17, 63, 20, 23),
(126, 17, 14, 63, 89, 20),
(127, 17, 2, 89, 63, 93),
(128, 17, 8, 93, 43, 20),
(129, 18, 3, 63, 93, 89),
(130, 18, 1, 93, 63, 20),
(131, 18, 5, 93, 63, 89),
(132, 18, 14, 93, 63, 89),
(133, 18, 17, 93, 89, 63),
(134, 18, 2, 63, 93, 20),
(135, 18, 8, 89, 93, 20),
(136, 19, 5, 89, 93, 43),
(137, 19, 1, 23, 93, 42),
(138, 19, 3, 23, 89, 63),
(139, 19, 17, 23, 93, 42),
(140, 19, 14, 93, 89, 23),
(141, 19, 8, 89, 93, 42),
(142, 19, 6, 23, 93, 89),
(143, 19, 2, 93, 63, 89),
(144, 20, 8, 89, 43, 20),
(145, 20, 5, 20, 89, 93),
(146, 20, 1, 20, 43, 93),
(147, 20, 17, 93, 20, 43),
(148, 20, 2, 89, 20, 42),
(149, 20, 3, 89, 93, 20),
(150, 20, 14, 89, 43, 20),
(151, 20, 10, 43, 93, 20),
(152, 20, 6, 93, 89, 43),
(153, 20, 13, 93, 43, 89);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 10.35.47.22:3306
-- Erstellungszeit: 08. Nov 2022 um 20:18
-- Server-Version: 8.0.30
-- PHP-Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `k42028_cloud`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_comments`
--

DROP TABLE IF EXISTS `MGP_comments`;
CREATE TABLE `MGP_comments` (
  `CID` int NOT NULL COMMENT 'Comment ID',
  `EID` tinyint NOT NULL COMMENT 'Event ID',
  `UID` tinyint NOT NULL COMMENT 'User ID',
  `Date` datetime DEFAULT NULL,
  `Comment` varchar(512) CHARACTER SET utf8mb4 DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `MGP_comments`
--

INSERT INTO `MGP_comments` (`CID`, `EID`, `UID`, `Date`, `Comment`) VALUES
(1, 5, 10, '2022-04-24 21:08:44', 'Quartararo ist einfach der Hammer, vor allem wenn man sich ansieht, wo\r\ndie anderen Yamaha-Fahrer herumfahren.\r\nUnd auch wenn der sympathische Ochse Miller sich zur&uuml;ckgehalten h&auml;tte,\r\nh&auml;tte mir das bei meinem Tip heute auch nicht geholfen ;-)<br>\r\nWar heute echt ein &Uuml;berrasschungsei - und dass am Ende der Zieleinlauf\r\nder ersten Startreihe entspricht, h&auml;tte ich echt nicht gedacht.\r\n'),
(2, 6, 1, '2022-05-01 18:34:41', 'Viele 2-Punkte Ergebnisse beim Tipspiel diesmal :-).<br>\r\nP1/P2 war nicht &uuml;berraschend, h&auml;tte aber auch andersrum sein k&ouml;nnen.<br>\r\nP3 h&auml;tte ich nicht wirklich erwartet, bei MM93 h&auml;tte ich eher auf einen Crash getippt.'),
(3, 7, 1, '2022-05-15 14:48:51', 'Wieder mal ein unerwartetes Ergebnis, FQ schlechter Start, Pecco patzt, Bastianini genial.'),
(4, 8, 3, '2022-05-28 16:30:41', 'Wird schwierig Morgen der Tipp. Hab mit jemand von Ducati geschrieben es soll Regnen morgen. Warten wir morgen frÃ¼h ab. '),
(5, 8, 1, '2022-05-29 14:47:36', 'Pecco auf 1 war im Trockenen keine Ãœberraschung, FQ auf 2 aber schon - hÃ¤tte ich nicht erwartet.\r\nAE41 wieder auf dem Podest, der wird langsam unheimlich...'),
(6, 9, 1, '2022-06-05 14:48:06', 'Mal wieder Null Punkte f&uuml;r alle Tipspiel-Teilnehmer :-) <br>\r\nWobei P2 von AE41 echt verschenkt wurde.\r\nFQ20 ist nun klarer WM Favorit, denk ich.'),
(7, 9, 10, '2022-06-05 22:12:09', 'Kompletter Aussetzer von AE41 und leider vorher schon von TN30.\r\nSchade, war auf das Duell FQ20 und PB63 echt gespannt.\r\nSch&ouml;n, dass Martin wieder bei der Musik ist.\r\n... und EWC war auch nicht von schlechten Eltern.'),
(8, 10, 1, '2022-06-19 14:49:12', 'Pecco zeigt Nerven und ist nun wohl aus dem Rennen um die WM - FQ20 wieder souver&auml;n, Zarco nicht ganz unerwartet vorn dabei.\r\nAE41 gut, aber nicht gut genug f&uuml;r die WM.'),
(9, 11, 1, '2022-06-26 15:35:43', 'Und wieder ein schwer vorhersagbares Resultat, bis auf P1 (hier gab es eigentlich nur die Wahl zwischen FQ20 und FB63 - wobei wohl auch AE41 ein Kandidat gewesen w&auml;re) - dahinter mal wieder nur falsche Tips, wobei ich mit MB72 nah dran war, aber knapp daneben ist eben auch vorbei :-)'),
(10, 13, 1, '2022-08-21 14:54:06', 'Zum ersten Mal nun 3-Punkte Tips - und das gleich zwei Mal :-)\r\nSo kann\'s weiter gehen...'),
(11, 13, 6, '2022-08-21 15:00:56', 'Jo, Q20 hat sich da sehr gut durchgesetzt, und JM war etwas zu schnell...// Beides gut f&uuml;r uns...'),
(12, 14, 6, '2022-09-04 14:47:01', 'Auch nicht schlecht: als Einziger das Podium richtig getippt, leider die falsche Reihenfolge. Daher 0 Punkte, das ist nicht sch&ouml;n. '),
(13, 14, 1, '2022-09-04 15:10:22', 'Ja, Jochen, so ist das Leben - knapp daneben ist auch vorbei :-)\r\nAlso auf ein Neues in Aragon...'),
(14, 16, 1, '2022-09-25 08:49:45', 'Und wieder ein unerwartetes Ergebnis, Null Punkte f&uuml;r alle Tipspieler :-)'),
(15, 17, 6, '2022-10-02 08:54:18', '43: hmm, wenn man w&uuml;sste, ob es sp&auml;ter regnet...'),
(16, 17, 6, '2022-10-02 11:42:46', '2 von 3 richtig auf dem Podium, 0 Punkte, na super! // Wieder mal ein sch&ouml;nes Rennen!'),
(17, 17, 1, '2022-10-02 11:52:43', 'ja, Regen ist ist immer besonders schwierig f&uuml;r Tips, JM43 hatte ich ja auf dem Schirm, aber nicht MO88, und dass FQ20 so untergeht war auch &uuml;berraschend - wie auch immer, sch&ouml;n dass die WM jetzt wieder offen ist, es wird nun richtig spannend'),
(18, 17, 6, '2022-10-02 21:03:58', 'Stimmt, f&uuml;r nen WM war die Leistung von Q20 bei weitem nicht ausreichend. Und ja: die ersten 5 haben alle noch Chancen. Wie Du sagst: Es ist und bleibt spannend.'),
(19, 20, 1, '2022-11-06 15:19:14', 'Ich denke, Pecco ist ein w&uuml;rdiger Weltmeister, er war &uuml;ber das Jahr der schnellste und hat eine nie da gewesene Aufholjagd hingelegt.\r\nAber nat&uuml;rlich auch Respekt f&uuml;r FQ, der halt ein minimal langsameres Motorrad hat.\r\nAlso danke an alle f&uuml;rs Mitmachen - auf ein Neues in 2023 !\r\n'),
(20, 20, 3, '2022-11-07 16:43:32', 'Martin wie war das der letzte muss ne Kiste Bier zum Sieger bringen die dann da getrunken wird. ::))))');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `MGP_comments`
--
ALTER TABLE `MGP_comments`
  ADD PRIMARY KEY (`CID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `MGP_comments`
--
ALTER TABLE `MGP_comments`
  MODIFY `CID` int NOT NULL AUTO_INCREMENT COMMENT 'Comment ID', AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
