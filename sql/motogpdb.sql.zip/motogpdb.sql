-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Erstellungszeit: 18. Apr 2022 um 09:54
-- Server-Version: 8.0.27
-- PHP-Version: 7.4.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `motogpdb`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_Events`
--

DROP TABLE IF EXISTS `MGP_Events`;
CREATE TABLE `MGP_Events` (
  `EID` tinyint NOT NULL,
  `Ort` varchar(64) NOT NULL,
  `Deadline` datetime NOT NULL,
  `P1` tinyint DEFAULT NULL,
  `P2` tinyint DEFAULT NULL,
  `P3` tinyint DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Daten für Tabelle `MGP_Events`
--

INSERT INTO `MGP_Events` (`EID`, `Ort`, `Deadline`, `P1`, `P2`, `P3`) VALUES
(1, 'Doha', '2022-03-05 10:00:00', 23, 33, 44),
(2, 'Mandalika', '2022-03-15 10:00:00', 88, 20, 5),
(3, 'Termas', '2022-03-15 10:00:00', 41, 89, 42),
(4, 'Austin', '2022-03-25 10:00:00', 23, 42, 43),
(5, 'Portimao', '2022-04-24 10:00:00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_Riders`
--

DROP TABLE IF EXISTS `MGP_Riders`;
CREATE TABLE `MGP_Riders` (
  `RID` tinyint NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Vorname` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Daten für Tabelle `MGP_Riders`
--

INSERT INTO `MGP_Riders` (`RID`, `Name`, `Vorname`) VALUES
(5, 'Zarco', 'Johann'),
(10, 'Marini', 'Luca'),
(20, 'Quartararo', 'Fabio'),
(23, 'Bastianini', 'Enea'),
(33, 'Binder', 'Brad'),
(36, 'Mir', 'Joan'),
(41, 'Espargaro', 'Aleix'),
(42, 'Rins', 'Alex'),
(43, 'Miller', 'Jack'),
(44, 'Espargaro', 'Pol'),
(63, 'Bagnaia', 'Francesco'),
(88, 'Oliveira', 'Miguel'),
(89, 'Martin', 'Jorge'),
(93, 'Marquez', 'Marc');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_Tips`
--

DROP TABLE IF EXISTS `MGP_Tips`;
CREATE TABLE `MGP_Tips` (
  `EID` tinyint NOT NULL,
  `UID` tinyint NOT NULL,
  `P1` tinyint NOT NULL,
  `P2` tinyint NOT NULL,
  `P3` tinyint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Daten für Tabelle `MGP_Tips`
--

INSERT INTO `MGP_Tips` (`EID`, `UID`, `P1`, `P2`, `P3`) VALUES
(1, 1, 93, 36, 89),
(1, 5, 23, 89, 93),
(2, 1, 20, 33, 63),
(2, 5, 5, 20, 63);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `MGP_users`
--

DROP TABLE IF EXISTS `MGP_users`;
CREATE TABLE `MGP_users` (
  `UID` tinyint NOT NULL,
  `Name` varchar(64) NOT NULL,
  `Vorname` varchar(64) NOT NULL,
  `Email` varchar(64) NOT NULL,
  `Passwort` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Daten für Tabelle `MGP_users`
--

INSERT INTO `MGP_users` (`UID`, `Name`, `Vorname`, `Email`, `Passwort`) VALUES
(1, 'Joss', 'Werner', 'werner@hoernerfranzracing.de', 't1242t'),
(2, 'Rendier', 'Udo', 'chezmoto32@gmail.com', '1234'),
(3, 'Metz', 'Bodo', 'bodo.metz@gmx.de', '1234'),
(4, 'Hauke', 'Christian', 'chris.hauke@gmx.de', '1234'),
(5, 'Friedrich', 'Wolfgang', 'wolfgang.d.friedrich@alice-dsl.net', '1234'),
(6, 'Treuz', 'Jochen', 'info@treuz.de', '1234'),
(7, 'Staengle', 'Rene', 'rene.staengle@gmail.com', '1234'),
(8, 'Beaujean', 'Damian', 'beaujean@ph1.uni-koeln.de', '1234');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `MGP_Events`
--
ALTER TABLE `MGP_Events`
  ADD PRIMARY KEY (`EID`);

--
-- Indizes für die Tabelle `MGP_Riders`
--
ALTER TABLE `MGP_Riders`
  ADD PRIMARY KEY (`RID`);

--
-- Indizes für die Tabelle `MGP_users`
--
ALTER TABLE `MGP_users`
  ADD PRIMARY KEY (`UID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `MGP_Events`
--
ALTER TABLE `MGP_Events`
  MODIFY `EID` tinyint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT für Tabelle `MGP_users`
--
ALTER TABLE `MGP_users`
  MODIFY `UID` tinyint NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
